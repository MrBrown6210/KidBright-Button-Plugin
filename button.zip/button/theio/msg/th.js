Blockly.Msg.BUTTON_EVENT_ON_PRESSED_TITLE1 = "เมื่อกดปุ่ม";
Blockly.Msg.BUTTON_EVENT_ON_PRESSED_TITLE2 = "จะ";
Blockly.Msg.BUTTON_EVENT_ON_PRESSED_TOOLTIP = "บล็อกภายใต้บล็อกใหญ่นี้ จะถูกกระทำเมื่อกดปุ่ม";
Blockly.Msg.BUTTON_EVENT_ON_PRESSED_HELPURL = "";