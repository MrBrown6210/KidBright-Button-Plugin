Blockly.Msg.BUTTON_EVENT_ON_PRESSED_TITLE1 = "When pressed";
Blockly.Msg.BUTTON_EVENT_ON_PRESSED_TITLE2 = "will do";
Blockly.Msg.BUTTON_EVENT_ON_PRESSED_TOOLTIP = "Do this on pressed button";
Blockly.Msg.BUTTON_EVENT_ON_PRESSED_HELPURL = "";